# P-TOPSIS 
This package is used to find the TOPSIS score and ranking of multiple-component data.

# Installation
```pip intall p-topsis```

# License
© 2020 Rajvir Singh 